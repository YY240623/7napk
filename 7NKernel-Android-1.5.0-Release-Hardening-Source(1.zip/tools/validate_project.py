#!/usr/bin/env python3
"""Static project sanity checks; this is not an Android build or device test."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/sevenn/kernel/MainActivity.kt"
CATALOG = ROOT / "app/src/main/java/com/sevenn/kernel/GlassParameterCatalog.kt"
TEST = ROOT / "app/src/test/java/com/sevenn/kernel/GlassParameterCatalogTest.kt"
MANIFEST = ROOT / "app/src/main/AndroidManifest.xml"
APP_GRADLE = ROOT / "app/build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-build.yml"
main = MAIN.read_text(encoding="utf-8")
catalog = CATALOG.read_text(encoding="utf-8")
app_gradle = APP_GRADLE.read_text(encoding="utf-8")
workflow = WORKFLOW.read_text(encoding="utf-8")

categories_match = re.search(r"internal val GlassCategories = listOf\((.*?)\)\n", catalog, re.S)
assert categories_match, "GlassCategories declaration missing"
categories = re.findall(r'"([^\"]+)"', categories_match.group(1))
assert len(categories) == 12, f"Expected 12 categories, found {len(categories)}"

core_match = re.search(r"val core = listOf\((.*?)\n    \)\n    val prefixes", catalog, re.S)
assert core_match, "Core parameter list missing"
core_entries = re.findall(r"GlassParam\(\d+,", core_match.group(1))
assert len(core_entries) == 8, f"Expected 8 effective parameters, found {len(core_entries)}"
assert "for (id in 9..243)" in catalog and "buildList(243)" in catalog

assert 'versionCode = 6' in app_gradle and 'versionName = "1.5.0"' in app_gradle
assert main.count("BuildConfig.VERSION_NAME") >= 1, "App UI version labels must match Gradle version"
assert "7NKernel-glass-v1" in main, "Versioned JSON import/export format missing"
assert "rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument())" in main
assert "rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument" in main
assert "getLaunchIntentForPackage" in main
assert "System.getProperty(\"os.version\")" in main
assert "onMotionChange" in main and "HapticFeedbackType.TextHandleMove" in main

assert TEST.is_file(), "JVM unit tests missing"
for test_name in ["catalogContainsExactly243UniqueSequentialParameters", "catalogContains12CategoriesAndEightEffectiveParameters", "everyParameterHasValidRangeAndDefault", "placeholderParametersAreExplicitlyNonLinked", "importClampsValuesAndSkipsUnknownIds", "importRejectsDuplicateKnownIds", "importRejectsNonFiniteValues", "importRejectsFilesWithoutKnownParameters", "catalogGenerationIsDeterministic", "eachParameterHasNonNegativeIdAndNonEmptyCategory"]:
    assert test_name in TEST.read_text(encoding="utf-8"), f"Missing test: {test_name}"
assert 'testImplementation("junit:junit:4.13.2")' in app_gradle
assert "sanitizeImportedGlassValues" in catalog
assert "total <= 1_048_576" in main, "Import size limit missing"
assert "check(editor.commit())" in main, "Import must commit atomically"

ET.parse(MANIFEST)
for required in ["settings.gradle.kts", "build.gradle.kts", "gradle.properties", "README.md"]:
    assert (ROOT / required).is_file(), f"Missing {required}"
assert 'confirmReset = true' in main and 'AlertDialog(' in main, "Reset confirmation dialog missing"
assert 'BuildConfig.VERSION_NAME' in main, "UI must read generated app version"
assert 'isMinifyEnabled = true' in app_gradle and 'proguard-rules.pro' in app_gradle
assert 'ANDROID_KEYSTORE_BASE64' in workflow and 'assembleRelease' in workflow
for task in [":app:lintDebug", ":app:testDebugUnitTest", ":app:assembleDebug"]:
    assert task in workflow, f"CI task missing: {task}"

print("STATIC CHECKS PASSED")
print(f"- categories: {len(categories)}")
print(f"- effective core parameters: {len(core_entries)}")
print("- placeholder parameters: 235")
print("- total generated parameters: 243")
print("- ten JVM catalog/import tests declared")
print("- reset confirmation and generated version label present")
print("- optional CI release signing is environment-secret based")
print("- import validation: atomic, duplicate-safe, finite values, 1 MB cap")
print("- manifest XML: valid")
print("- app version labels and CI build/test/lint steps: consistent")
print("NOTE: static checks only; CI must still compile, test, lint and assemble the APK.")
