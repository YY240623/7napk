package com.sevenn.kernel

internal val GlassCategories = listOf(
    "光学与折射", "形状与表面", "边缘高光", "外阴影", "内阴影", "背景与主题",
    "轨道与触摸光斑", "液滴融合", "胶囊按钮", "液态开关", "液态滑块", "液态标签"
)

internal data class GlassParam(
    val id: Int, val category: String, val name: String, val min: Float, val max: Float,
    val step: Float, val default: Float, val unit: String = "", val cssVar: String? = null
)

internal fun buildGlassParams(): List<GlassParam> {
    val core = listOf(
        GlassParam(1, GlassCategories[0], "背景模糊度", 0f, 100f, 1f, 40f, "px", "--g-blur"),
        GlassParam(2, GlassCategories[1], "折射不透明度", 0f, 100f, 1f, 12f, "%", "--g-alpha"),
        GlassParam(3, GlassCategories[0], "滤镜饱和度", 100f, 300f, 1f, 200f, "%", "--g-saturate"),
        GlassParam(4, GlassCategories[0], "表面对比度", 50f, 200f, 1f, 100f, "%", "--g-contrast"),
        GlassParam(5, GlassCategories[0], "全局亮度", 50f, 200f, 1f, 100f, "%", "--g-brightness"),
        GlassParam(6, GlassCategories[1], "边缘透明度", 0f, 100f, 1f, 15f, "%", "--g-border-alpha"),
        GlassParam(7, GlassCategories[1], "组件圆角", 0f, 40f, 1f, 24f, "px", "--g-radius"),
        GlassParam(8, GlassCategories[2], "顶部高光", 0f, 5f, 1f, 1f, "px", "--g-highlight")
    )
    val prefixes = listOf("色散补偿", "焦散偏移", "菲涅尔反射", "漫反射衰减", "高光平滑", "内阴影模糊", "轨道光晕", "水滴张力")
    return buildList(243) {
        addAll(core)
        for (id in 9..243) {
            add(GlassParam(id, GlassCategories[id % GlassCategories.size],
                prefixes[id % prefixes.size] + " ${((id + 9) / 10)}", 0f, 100f, 1f, 50f))
        }
    }
}



internal data class ImportedGlassValue(val id: Int, val value: Float)

/** Validates a complete import before any preference is changed. Unknown IDs are skipped
 * for forward compatibility; duplicate known IDs and non-finite values reject the file. */
internal fun sanitizeImportedGlassValues(entries: List<ImportedGlassValue>): Map<Int, Float> {
    val catalog = buildGlassParams().associateBy { it.id }
    val result = linkedMapOf<Int, Float>()
    for (entry in entries) {
        val parameter = catalog[entry.id] ?: continue
        require(entry.value.isFinite()) { "参数 ${entry.id} 不是有效数字" }
        require(entry.id !in result) { "参数 ${entry.id} 重复" }
        result[entry.id] = entry.value.coerceIn(parameter.min, parameter.max)
    }
    require(result.isNotEmpty()) { "配置文件中没有可识别的参数" }
    return result
}
