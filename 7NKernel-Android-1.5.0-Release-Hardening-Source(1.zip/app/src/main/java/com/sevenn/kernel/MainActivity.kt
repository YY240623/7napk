package com.sevenn.kernel

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

private val Ink = Color(0xFF172033)
private val Muted = Color(0xFF7B8496)
private val Blue = Color(0xFF3978F6)
private val Mint = Color(0xFF28B88A)
private val Page = Color(0xFFF2F5FA)

private data class GlassStyle(
    val blur: Float = 40f, val alpha: Float = 12f, val saturation: Float = 200f,
    val contrast: Float = 100f, val brightness: Float = 100f, val border: Float = 15f,
    val radius: Float = 24f, val highlight: Float = 1f
)

private fun readStyle(prefs: android.content.SharedPreferences): GlassStyle = GlassStyle(
    prefs.getFloat("param_1", 40f), prefs.getFloat("param_2", 12f),
    prefs.getFloat("param_3", 200f), prefs.getFloat("param_4", 100f),
    prefs.getFloat("param_5", 100f), prefs.getFloat("param_6", 15f),
    prefs.getFloat("param_7", 24f), prefs.getFloat("param_8", 1f)
)

private fun styleFrom(values: List<Float>) = GlassStyle(
    values[0], values[1], values[2], values[3], values[4], values[5], values[6], values[7]
)

private fun exportParams(prefs: android.content.SharedPreferences): String {
    val arr = JSONArray()
    buildGlassParams().forEach { p ->
        arr.put(JSONObject().put("id", p.id).put("value", prefs.getFloat("param_${p.id}", p.default)))
    }
    return JSONObject().put("format", "7NKernel-glass-v1").put("parameters", arr).toString(2)
}

private fun importParams(prefs: android.content.SharedPreferences, json: String): Int {
    val root = JSONObject(json)
    require(root.optString("format") == "7NKernel-glass-v1") { "配置文件格式不匹配" }
    val arr = root.getJSONArray("parameters")
    require(arr.length() <= 243) { "参数数量超出支持范围" }
    val entries = (0 until arr.length()).map { index ->
        val item = arr.getJSONObject(index)
        val rawValue = item.optDouble("value", Double.NaN)
        require(rawValue.isFinite() && rawValue in -Float.MAX_VALUE.toDouble()..Float.MAX_VALUE.toDouble()) {
            "第 ${index + 1} 项参数数值无效"
        }
        ImportedGlassValue(item.optInt("id", -1), rawValue.toFloat())
    }
    // Validate the whole document first: a malformed file must never partially overwrite settings.
    val sanitized = sanitizeImportedGlassValues(entries)
    val editor = prefs.edit()
    sanitized.forEach { (id, value) -> editor.putFloat("param_$id", value) }
    check(editor.commit()) { "配置保存失败" }
    return sanitized.size
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("7n_preferences", MODE_PRIVATE)
        setContent { SevenNApp(prefs) }
    }
}

private enum class Tab(val title: String) { HOME("主页"), DEVICE("设备中心"), SETTINGS("设置") }

@Composable
private fun SevenNApp(prefs: android.content.SharedPreferences) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var glassOpen by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }
    var style by remember { mutableStateOf(readStyle(prefs)) }
    var motionEnabled by remember { mutableStateOf(prefs.getBoolean("motion", true)) }
    var importRevision by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) runCatching {
            val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    require(total <= 1_048_576) { "配置文件不能超过 1 MB" }
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            } ?: error("无法读取配置文件")
            val json = bytes.toString(Charsets.UTF_8)
            val count = importParams(prefs, json)
            style = readStyle(prefs)
            importRevision++
            notice = "已导入 $count 项参数"
        }.onFailure { notice = "导入失败：${it.message ?: "文件无效"}" }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(exportParams(prefs)) }
                ?: error("无法写入文件")
            notice = "参数配置已导出"
        }.onFailure { notice = "导出失败：${it.message ?: "未知错误"}" }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Mint, background = Page, surface = Color.White, onSurface = Ink)) {
        CompositionLocalProvider(LocalGlassStyle provides style) {
            Box(Modifier.fillMaxSize().background(Page)) {
                val blur = style.blur.dp.coerceIn(0.dp, 100.dp)
                Box(Modifier.offset(x = (-70).dp, y = 70.dp).size(230.dp).blur(blur)
                    .background(Color(0x557BA8FF), CircleShape))
                Box(Modifier.align(Alignment.BottomEnd).offset(x = 80.dp, y = (-80).dp)
                    .size(260.dp).blur(blur).background(Color(0x554BD7B2), CircleShape))
                Column(Modifier.fillMaxSize().statusBarsPadding()) {
                    AnimatedContent(
                        targetState = glassOpen to tab,
                        transitionSpec = {
                            val duration = if (motionEnabled) 260 else 1
                            (fadeIn(tween(duration)) + slideInHorizontally(tween(duration)) { it / 18 }) togetherWith
                                (fadeOut(tween(duration)) + slideOutHorizontally(tween(duration)) { -it / 24 })
                        }, label = "7n-page"
                    ) { (isGlass, currentTab) ->
                        if (isGlass) GlassConsole(
                            prefs, importRevision, onBack = { style = readStyle(prefs); glassOpen = false },
                            onStyleChange = { style = it }, notify = { notice = it },
                            onImport = { importLauncher.launch(arrayOf("application/json", "text/*")) },
                            onExport = { exportLauncher.launch("7NKernel-glass-config.json") }
                        ) else when (currentTab) {
                            Tab.HOME -> HomePage(
                                onOpenGlass = { glassOpen = true },
                                onLaunchGame = {
                                    val packages = listOf("com.tencent.tmgp.pubgmhd", "com.tencent.ig")
                                    val launch = packages.firstNotNullOfOrNull { context.packageManager.getLaunchIntentForPackage(it) }
                                    if (launch != null) runCatching { context.startActivity(launch) }
                                        .onFailure { notice = "启动失败：${it.message}" }
                                    else notice = "未找到已安装的目标游戏"
                                }
                            )
                            Tab.DEVICE -> DevicePage()
                            Tab.SETTINGS -> SettingsPage(
                                prefs, onOpenGlass = { glassOpen = true }, notify = { notice = it },
                                onMotionChange = { motionEnabled = it }, onResetAll = { style = GlassStyle(); motionEnabled = true; importRevision++ }, onImport = { importLauncher.launch(arrayOf("application/json", "text/*")) },
                                onExport = { exportLauncher.launch("7NKernel-glass-config.json") }
                            )
                        }
                    }
                    if (!glassOpen) NavigationBar(containerColor = Color.White.copy(alpha = .84f)) {
                        Tab.entries.forEach { item ->
                            NavigationBarItem(
                                selected = tab == item, onClick = { tab = item },
                                icon = { Icon(when (item) {
                                    Tab.HOME -> Icons.Rounded.Home
                                    Tab.DEVICE -> Icons.Rounded.Memory
                                    Tab.SETTINGS -> Icons.Rounded.Settings
                                }, contentDescription = item.title) },
                                label = { Text(item.title, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue,
                                    indicatorColor = Blue.copy(alpha = .10f))
                            )
                        }
                    }
                }
                if (notice.isNotBlank()) {
                    LaunchedEffect(notice) { android.widget.Toast.makeText(context, notice, android.widget.Toast.LENGTH_LONG).show(); notice = "" }
                }
            }
        }
    }
}

private val LocalGlassStyle = staticCompositionLocalOf { GlassStyle() }

@Composable
private fun PageFrame(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp).padding(top = 20.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
            Text(subtitle, fontSize = 13.sp, color = Muted)
        }
        content()
    }
}

private fun adjustColor(color: Color, saturation: Float, contrast: Float, brightness: Float): Color {
    val gray = color.red * .299f + color.green * .587f + color.blue * .114f
    val sat = (saturation / 200f).coerceIn(.25f, 1.5f)
    val con = (contrast / 100f).coerceIn(.5f, 1.5f)
    val bri = (brightness / 100f).coerceIn(.5f, 1.5f)
    fun channel(v: Float): Float = (((gray + (v - gray) * sat - .5f) * con + .5f) * bri).coerceIn(0f, 1f)
    return Color(channel(color.red), channel(color.green), channel(color.blue), color.alpha)
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val s = LocalGlassStyle.current
    val radius = s.radius.dp.coerceIn(4.dp, 40.dp)
    val fillAlpha = (.30f + s.alpha / 180f).coerceIn(.30f, .92f)
    val start = adjustColor(Color.White.copy(alpha = fillAlpha), s.saturation, s.contrast, s.brightness)
    val end = adjustColor(Color(0xFFEAF1FF).copy(alpha = fillAlpha * .82f), s.saturation, s.contrast, s.brightness)
    Column(modifier.shadow((2f + s.highlight * 2f).dp, RoundedCornerShape(radius))
        .clip(RoundedCornerShape(radius))
        .background(Brush.linearGradient(listOf(start, end)))
        .border((.5f + s.highlight.coerceIn(0f, 5f) * .35f).dp,
            Color.White.copy(alpha = (.12f + s.border / 120f).coerceIn(.12f, .95f)), RoundedCornerShape(radius))
        .padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun HomePage(onOpenGlass: () -> Unit, onLaunchGame: () -> Unit) {
    PageFrame("7NKernel", "设备状态与快捷入口") {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(Blue, Color(0xFF8A72F7)))), contentAlignment = Alignment.Center) {
                    Text("7N", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                }
                Column(Modifier.weight(1f)) {
                    Text("欢迎使用 7NKernel", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Android 原生版 · ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.CheckCircle, null, tint = Mint)
            }
        }
        SectionLabel("设备概览")
        GlassCard(Modifier.fillMaxWidth()) {
            InfoLine("设备型号", "${Build.MANUFACTURER} ${Build.MODEL}")
            InfoLine("Android 版本", "Android ${Build.VERSION.RELEASE}")
            InfoLine("SDK", Build.VERSION.SDK_INT.toString())
            InfoLine("CPU ABI", Build.SUPPORTED_ABIS.firstOrNull() ?: "未知")
        }
        SectionLabel("快捷启动")
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFFFE8B8)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SportsEsports, null, tint = Color(0xFFB87916))
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("应用启动器", fontWeight = FontWeight.Bold)
                    Text("通过 Android 系统启动已安装应用", color = Muted, fontSize = 11.sp)
                }
            }
            Button(onClick = onLaunchGame, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(6.dp)); Text("启动目标游戏")
            }
            Text("仅负责打开已安装应用，不修改游戏数据或进程。", color = Muted, fontSize = 11.sp)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Waves, null, tint = Blue, modifier = Modifier.size(26.dp))
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                    Text("液态玻璃控制台", fontWeight = FontWeight.Bold)
                    Text("243 项参数 · 8 项实际影响界面", color = Muted, fontSize = 12.sp)
                }
                Text("打开", color = Blue, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable { onOpenGlass() }.padding(8.dp))
            }
        }
        Text("设备信息来自 Android 公开 API；本应用不会执行内核写入或游戏进程注入。", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun DevicePage() {
    PageFrame("设备中心", "Android 系统信息与兼容性") {
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Memory, null, tint = Blue, modifier = Modifier.size(28.dp))
                Text("系统信息", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            InfoLine("品牌", Build.BRAND); InfoLine("制造商", Build.MANUFACTURER)
            InfoLine("型号", Build.MODEL); InfoLine("产品代号", Build.PRODUCT)
            InfoLine("设备代号", Build.DEVICE); InfoLine("Android", Build.VERSION.RELEASE)
            InfoLine("API Level", Build.VERSION.SDK_INT.toString())
            InfoLine("安全补丁", Build.VERSION.SECURITY_PATCH)
            InfoLine("ABI 列表", Build.SUPPORTED_ABIS.joinToString())
            if (Build.VERSION.SDK_INT >= 31) InfoLine("SoC 制造商", Build.SOC_MANUFACTURER)
            if (Build.VERSION.SDK_INT >= 31) InfoLine("SoC 型号", Build.SOC_MODEL)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("内核与运行环境", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            InfoLine("内核版本", System.getProperty("os.version") ?: "系统未提供")
            InfoLine("运行时", System.getProperty("java.vm.name") ?: "未知")
            InfoLine("架构", System.getProperty("os.arch") ?: "未知")
            Text("此处显示系统实际提供的信息，不根据 ABI 猜测内核版本。驱动状态不会被伪装为已刷入。", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun SettingsPage(
    prefs: android.content.SharedPreferences, onOpenGlass: () -> Unit, notify: (String) -> Unit,
    onMotionChange: (Boolean) -> Unit, onResetAll: () -> Unit, onImport: () -> Unit, onExport: () -> Unit
) {
    var motion by remember { mutableStateOf(prefs.getBoolean("motion", true)) }
    var haptics by remember { mutableStateOf(prefs.getBoolean("haptics", true)) }
    var confirmReset by remember { mutableStateOf(false) }
    PageFrame("设置", "应用偏好与本地数据") {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("体验设置", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            PrefSwitch("高级页面动效", "关闭后使用即时页面切换", motion) {
                motion = it; prefs.edit().putBoolean("motion", it).apply(); onMotionChange(it)
            }
            HorizontalDivider(color = Ink.copy(.07f))
            PrefSwitch("触感反馈", "为开关与关键操作提供触感提示", haptics) {
                haptics = it; prefs.edit().putBoolean("haptics", it).apply()
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("液态玻璃外观", fontWeight = FontWeight.Bold)
                    Text("12 个分类 · 243 项参数", color = Muted, fontSize = 12.sp)
                }
                Text("配置", color = Blue, modifier = Modifier.clickable { onOpenGlass() }.padding(8.dp))
            }
            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.FileOpen, null); Spacer(Modifier.width(8.dp)); Text("导入 JSON 配置") }
            OutlinedButton(onClick = onExport, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("导出 JSON 配置") }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("数据管理", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("配置保存在本机应用私有偏好存储中。卸载应用会清除这些数据。", color = Muted, fontSize = 12.sp)
            OutlinedButton(onClick = { confirmReset = true },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Rounded.RestartAlt, null); Spacer(Modifier.width(6.dp)); Text("恢复全部默认设置")
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("应用信息", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            InfoLine("版本", BuildConfig.VERSION_NAME)
            InfoLine("最低系统版本", "Android 8.0 (API 26)")
            InfoLine("目标系统版本", "Android 15 (API 35)")
            Text("本应用不包含内核刷写、游戏注入或反作弊修改功能。设备信息仅通过 Android 公开接口读取。", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Text("7NKernel · Android ${BuildConfig.VERSION_NAME}", color = Muted, fontSize = 11.sp)
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("恢复全部默认设置？") },
            text = { Text("这会清除本应用保存的外观参数和偏好设置，且无法自动撤销。建议先导出配置备份。") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    prefs.edit().clear().apply()
                    motion = true
                    haptics = true
                    onResetAll()
                    notify("本地偏好已恢复默认值")
                }) { Text("确认恢复") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("取消") }
            }
        )
    }
}

@Composable
private fun GlassConsole(
    prefs: android.content.SharedPreferences, importRevision: Int, onBack: () -> Unit,
    onStyleChange: (GlassStyle) -> Unit, notify: (String) -> Unit,
    onImport: () -> Unit, onExport: () -> Unit
) {
    val definitions = remember { buildGlassParams() }
    val values = remember { mutableStateListOf<Float>().apply {
        definitions.forEach { p -> add(prefs.getFloat("param_${p.id}", p.default)) }
    } }
    var category by remember { mutableStateOf(GlassCategories.first()) }
    var search by remember { mutableStateOf("") }
    var expandedInfo by remember { mutableStateOf(false) }
    LaunchedEffect(importRevision) {
        if (importRevision > 0) {
            definitions.forEachIndexed { i, p -> values[i] = prefs.getFloat("param_${p.id}", p.default) }
            onStyleChange(styleFrom(values))
        }
    }
    val filtered = remember(category, search, values.toList()) {
        if (search.isNotBlank()) definitions.filter { it.name.contains(search.trim(), ignoreCase = true) || it.category.contains(search.trim(), ignoreCase = true) }
        else definitions.filter { it.category == category }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(top = 8.dp, bottom = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, null) }
            Column(Modifier.weight(1f)) {
                Text("液态玻璃控制台", fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, color = Ink)
                Text("${definitions.size} 项参数 · ${definitions.count { it.cssVar != null }} 项联动", color = Muted, fontSize = 11.sp)
            }
            Text("保存", color = Blue, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                val editor = prefs.edit()
                definitions.forEachIndexed { i, p -> editor.putFloat("param_${p.id}", values[i]) }
                editor.apply(); notify("243 项参数已保存")
            }.padding(10.dp))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(118.dp).clip(RoundedCornerShape(LocalGlassStyle.current.radius.dp.coerceIn(4.dp, 40.dp)))
                .background(Brush.linearGradient(listOf(Color(0xFF6578B9), Color(0xFF8B68C7), Color(0xFF49BFA4)))), contentAlignment = Alignment.Center) {
                Column(Modifier.padding(16.dp).fillMaxWidth(.86f).clip(RoundedCornerShape(18.dp))
                    .background(Color.White.copy(alpha = (.30f + values[1] / 180f).coerceIn(.3f, .92f)))
                    .border(1.dp, Color.White.copy(alpha = .8f), RoundedCornerShape(18.dp)).padding(14.dp)) {
                    Text("7NKernel", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Ink)
                    Text("Liquid glass · Live preview", color = Muted, fontSize = 11.sp)
                }
            }
            Text("预览会实时响应 8 项核心样式参数；其余 235 项按原 HTML 定义为预留实验参数，不会虚报为已生效。", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, placeholder = { Text("搜索 243 项参数") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
            trailingIcon = { if (search.isNotEmpty()) IconButton(onClick = { search = "" }) { Icon(Icons.Rounded.Close, null) } })
        if (search.isBlank()) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 10.dp)) {
                item {
                    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(GlassCategories) { name ->
                            FilterChip(selected = category == name, onClick = { category = name }, label = { Text(name, maxLines = 1) })
                        }
                    }
                }
                item { PresetRow(onPreset = { preset ->
                    definitions.forEachIndexed { i, p -> values[i] = preset[i] }
                    onStyleChange(styleFrom(values)); notify("已应用外观预设，保存后生效")
                }, definitions = definitions) }
                items(filtered, key = { it.id }) { p ->
                    val index = p.id - 1
                    ParamCard(p, values[index], onChange = { v ->
                        values[index] = v
                        if (p.cssVar != null) onStyleChange(styleFrom(values))
                    })
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 10.dp)) {
                if (filtered.isEmpty()) item { Text("没有找到相关参数", color = Muted, modifier = Modifier.padding(24.dp)) }
                items(filtered, key = { it.id }) { p ->
                    ParamCard(p, values[p.id - 1], onChange = { v ->
                        values[p.id - 1] = v
                        if (p.cssVar != null) onStyleChange(styleFrom(values))
                    })
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = {
                values.indices.forEach { values[it] = definitions[it].default }
                onStyleChange(styleFrom(values)); notify("参数已恢复默认，点击保存以持久化")
            }, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.RestartAlt, null); Text("重置") }
            OutlinedButton(onClick = onImport, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.FileOpen, null); Text("导入") }
            Button(onClick = onExport, modifier = Modifier.weight(1f)) { Icon(Icons.Rounded.FileDownload, null); Text("导出") }
        }
        Text("提示：搜索可跨分类查找；分类列表展示完整 243 项。", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun PresetRow(definitions: List<GlassParam>, onPreset: (List<Float>) -> Unit) {
    val base = definitions.map { it.default }
    val soft = base.toMutableList().apply { this[0] = 24f; this[1] = 65f; this[2] = 150f; this[6] = 28f; this[7] = 2f }
    val vivid = base.toMutableList().apply { this[0] = 60f; this[1] = 82f; this[2] = 280f; this[3] = 125f; this[6] = 30f; this[7] = 3f }
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item { AssistChip(onClick = { onPreset(base) }, label = { Text("默认") }, leadingIcon = { Icon(Icons.Rounded.Refresh, null) }) }
        item { AssistChip(onClick = { onPreset(soft) }, label = { Text("柔和") }) }
        item { AssistChip(onClick = { onPreset(vivid) }, label = { Text("鲜明") }) }
    }
}

@Composable
private fun ParamCard(param: GlassParam, value: Float, onChange: (Float) -> Unit) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(param.name, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(if (param.cssVar != null) "核心样式 · 实时联动" else "实验预留参数 · 当前不影响界面",
                    color = Muted, fontSize = 10.sp)
            }
            Text("${value.roundToInt()}${param.unit}", color = Blue, fontWeight = FontWeight.Bold)
        }
        Slider(value = value.coerceIn(param.min, param.max), onValueChange = onChange,
            valueRange = param.min..param.max, steps = ((param.max - param.min) / param.step).toInt().coerceAtMost(1000) - 1)
    }
}

@Composable
private fun PrefSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val haptics = LocalHapticFeedback.current
    val enabled = LocalContext.current.getSharedPreferences("7n_preferences", android.content.Context.MODE_PRIVATE).getBoolean("haptics", true)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.SemiBold); Text(desc, color = Muted, fontSize = 11.sp) }
        Switch(checked = checked, onCheckedChange = { if (enabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove); onChange(it) })
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.width(12.dp))
        Text(value.ifBlank { "未知" }, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SectionLabel(text: String) { Text(text, color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
