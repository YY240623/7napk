package com.sevenn.kernel

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GlassParameterCatalogTest {
    private val params = buildGlassParams()

    @Test fun catalogContainsExactly243UniqueSequentialParameters() {
        assertEquals(243, params.size)
        assertEquals((1..243).toList(), params.map { it.id })
        assertEquals(243, params.map { it.id }.toSet().size)
    }

    @Test fun catalogContains12CategoriesAndEightEffectiveParameters() {
        assertEquals(12, GlassCategories.size)
        assertEquals(8, params.count { it.cssVar != null })
        assertEquals(235, params.count { it.cssVar == null })
        assertTrue(params.all { it.category in GlassCategories })
    }

    @Test fun everyParameterHasValidRangeAndDefault() {
        assertTrue(params.all { it.name.isNotBlank() })
        assertTrue(params.all { it.min <= it.default && it.default <= it.max })
        assertTrue(params.all { it.step > 0f })
        assertFalse(params.take(8).any { it.cssVar.isNullOrBlank() })
    }

    @Test fun placeholderParametersAreExplicitlyNonLinked() {
        assertTrue(params.drop(8).all { it.cssVar == null })
    }

    @Test fun importClampsValuesAndSkipsUnknownIds() {
        val result = sanitizeImportedGlassValues(listOf(
            ImportedGlassValue(1, 500f), ImportedGlassValue(999, 12f)
        ))
        assertEquals(mapOf(1 to 100f), result)
    }

    @Test fun importRejectsDuplicateKnownIds() {
        val result = runCatching { sanitizeImportedGlassValues(listOf(
            ImportedGlassValue(1, 20f), ImportedGlassValue(1, 30f)
        )) }
        assertTrue(result.isFailure)
    }

    @Test fun importRejectsNonFiniteValues() {
        assertTrue(runCatching { sanitizeImportedGlassValues(listOf(ImportedGlassValue(1, Float.NaN))) }.isFailure)
        assertTrue(runCatching { sanitizeImportedGlassValues(listOf(ImportedGlassValue(1, Float.POSITIVE_INFINITY))) }.isFailure)
    }

    @Test fun importRejectsFilesWithoutKnownParameters() {
        assertTrue(runCatching { sanitizeImportedGlassValues(listOf(ImportedGlassValue(999, 1f))) }.isFailure)
    }

    @Test fun catalogGenerationIsDeterministic() {
        assertEquals(buildGlassParams(), buildGlassParams())
    }

    @Test fun eachParameterHasNonNegativeIdAndNonEmptyCategory() {
        assertTrue(params.all { it.id > 0 && it.category.isNotBlank() })
    }

}
